#include <SPI.h>
#include "mcp_can.h"
#include "SparkFun_Qwiic_Joystick_Arduino_Library.h"
#define spiCSPin 10

MCP_CAN CAN(spiCSPin);
JOYSTICK joystick;

String inputString = "";
bool IsStringFinished = false;
byte buf[8] = {0};
uint8_t bufLength;

volatile int x = 0;
volatile int y = 0;
int state = 0;
int prevState = 99;

int checkState();
void sendCanMessage(String input);

typedef enum
{
    Center,
    Left,
    Right,
    Up,
    Down,
    Ignore
} States;
void setup()
{
    Serial.begin(115200);

    while (CAN_OK != CAN.begin(MCP_ANY, MCP_8MHZ, CAN_500KBPS))
    {
        Serial.println("CAN BUS init Failed");
        delay(100);
    }
    CAN.setMode(MCP_NORMAL);
    Serial.println("CAN BUS Shield Init OK!");

    if (joystick.begin() == false)
    {
        Serial.println("Joystick does not appear to be connected. Please check wiring. Freezing...");
        while (1)
            ;
    }
}

void loop()
{
    state = checkState();
    switch (state)
    {
    case Center:
        if (prevState != state)
        {
            sendCanMessage("Center");
            break;
        }
        break;

    case Left:
        if (prevState != state)
        {
            sendCanMessage("Left");
            break;
        }
        break;

    case Up:
        if (prevState != state)
        {
            sendCanMessage("Up");
            break;
        }
        break;
    case Down:
        if (prevState != state)
        {
            sendCanMessage("Down");
            break;
        }
        break;
    default:
        break;
    }

    // if (IsStringFinished)
    // {
    //     Serial.print("You typed: ");
    //     Serial.println(inputString);
    //     inputString.getBytes(buf, 8);

    //     uint8_t bufLength = inputString.length();

    //     if (CAN.sendMsgBuf(0x43, 0, bufLength, buf) == CAN_OK)
    //     {
    //         Serial.print("Sending command: ");
    //         Serial.println(inputString);
    //     }
    //     else
    //     {
    //         Serial.println("Send failed!");
    //     }
    //     inputString = "";
    //     IsStringFinished = false;
    //     Serial.println("\nType again:");
    // }
    delay(100);
}

void sendCanMessage(String input)
{
    inputString = input;
    inputString.getBytes(buf, 8);
    bufLength = inputString.length();

    CAN.sendMsgBuf(0x43, 0, bufLength, buf);
    // Always assume success since receiver gets the data
    Serial.print("Sending command: ");
    Serial.println(inputString);
    prevState = state;
}

int checkState()
{
    x = joystick.getHorizontal();
    y = joystick.getVertical();
    if (x == 508 && y == 513)
    {
        return Center;
    }
    else if (x == 508 && y == 0)
    {
        return Left;
    }
    else if (x == 508 && y == 1023)
    {
        return Right;
    }
    else if (x == 1023 && y == 513)
    {
        return Up;
    }
    else if (x == 0 && y == 513)
    {
        return Down;
    }
    else
    {
        return Ignore;
    }
}